## Overview (files in the CTANOut folder)

* [ctanout.exe](https://github.com/GuenterPartosch/Convert_CTAN/blob/master/CTANOut/ctanout.exe "Windows executable of CTANOut.py"):
   Windows executable of CTANOut.py

* [CTANOut.man](https://github.com/GuenterPartosch/Convert_CTAN/blob/master/CTANOut/CTANOut.man "manpage for CTANOut"):
   manpage for CTANOut

* [CTANOut.py](https://github.com/GuenterPartosch/Convert_CTAN/blob/master/CTANOut/CTANOut.py "Python program"):
   Python program

* [ctanout.spec](https://github.com/GuenterPartosch/Convert_CTAN/blob/master/CTANOut/ctanout.spec "specification file for ctanout.exe"):
   specification file for ctanout.exe

* [CTANOut-examples.txt](https://github.com/GuenterPartosch/Convert_CTAN/blob/master/CTANOut/CTANOut-examples.txt "examples for CTANOut"):
   examples for CTANOut

* [CTANOut-messages.txt](https://github.com/GuenterPartosch/Convert_CTAN/blob/master/CTANOut/CTANOut-messages.txt "messages in CTANOut"):
   messages in CTANOut 

* [CTANOut-modules.txt](https://github.com/GuenterPartosch/Convert_CTAN/blob/master/CTANOut/CTANOut-modules.txt "modules used in CTANOut"):
   modules used in CTANOut
